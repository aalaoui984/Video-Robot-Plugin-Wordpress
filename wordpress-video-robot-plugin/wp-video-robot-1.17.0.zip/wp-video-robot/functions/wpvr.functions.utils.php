<?php
	
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.admin.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.core.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.options.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.render.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.strings.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.time.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.ui.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.urls.php' );
	require_once( WPVR_PATH . '/functions/utils/wpvr.functions.utils.videos.php' );
	