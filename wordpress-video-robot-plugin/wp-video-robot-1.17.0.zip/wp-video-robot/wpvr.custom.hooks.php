<?php
	

	
	// //Adds the video service comments count to the available dataFiller options
	// add_filter( 'wpvr_extend_dataFillers_options', 'wpvr_add_comments_todataFillers', 100, 1 );
	// function wpvr_add_comments_todataFillers( $options ) {
	// 	$options['wpvr_video_service_comments'] = __( 'Video Original Comments', WPVR_LANG );
	//
	// 	return $options;
	// }
	
	//add_filter( 'the_content', array( $this, 'autoembed' ), 8 );
	//remove_filter('the_content', array('WP_Embed' , 'autoembed' ) , 8 );
	
	//Adds the video service comments count value to the video meta right before adding the video
	// add_filter( 'wpvr_extend_video_metas', 'wpvr_add_comments_to_video_meta', 100, 2 );
	// function wpvr_add_comments_to_video_meta( $video_meta, $videoItem ) {
	// 	$video_meta['wpvr_video_service_comments'] = $videoItem['comments'];
	//
	// 	return $video_meta;
	// }
