<?php

	/***************    WPVR CONFIG FILE    ***************/
	/***************    More Info about the advanced configuration on https://support.wpvideorobot.com/tutorials/advanced-configuration/ ***************/


	define( 'WPVR_API_DEBUG_MODE', false );

	define( 'WPVR_API_RESPONSE_DEBUG', false );

	define( 'WPVR_ENABLE_ASYNC_DEBUG', false );

	define( 'WPVR_META_DEBUG_MODE', false );

	define( 'WPVR_DISABLE_VIDEO_META_CUSTOM_TABLE', true );

	define( 'WPVR_DEFAULT_VIDEO_SLUG', 'wpvr_video' );

	define( 'WPVR_CHECK_ADDONS_UPDATES', false );

	define( 'WPVR_DISABLE_BLACK_BARS_REMOVER', false );

	define( 'WPVR_CHECK_PLUGIN_UPDATES', true );

	define( 'WPVR_DEFER_MAX_VALUE', 100 );

	define( 'WPVR_ASYNC_ADDING_BUFFER', 3 );

	define( 'WPVR_ENABLE_THUMB_CORRECTION', false );

	define( 'WPVR_ENABLE_THUMB_DEFAULT_SIZES', true );

	define( 'WPVR_FORCE_EXTERNAL_THUMB_HARD_CROP', false );

	define( 'WPVR_FORCE_EXTERNAL_THUMB_SSL', true );

	define( 'WPVR_CRON_ENDPOINT', 'automation' );

	define( 'WPVR_ASYNC_ENDPOINT', 'async' );

	define( 'WPVR_ENABLE_TEMPLATER', true );

	define( 'WPVR_ENABLE_SANDBOX', false );

	define( 'WPVR_IS_LOCKED_OUT', false );

	define( 'WPVR_MAX_WANTED_VIDEOS', false );

	define( 'WPVR_TAGS_FROM_TITLE_ENABLE', false );

	define( 'WPVR_ACCEPT_EMPTY_SOURCE_NAMES', false );

	define( 'WPVR_MAX_POSTING_CATS', 255 );

	define( 'WPVR_UNCATEGORIZED', 'uncategorized' );

	define( 'WPVR_MANAGE_LAYOUT', 'bgrid' );

	define( 'WPVR_MANAGE_PERPAGE', 20 );

	define( 'WPVR_DEFERRED_PERPAGE', 40 );

	define( 'WPVR_UNWANTED_PERPAGE', 40 );

	define( 'WPVR_ENABLE_HARD_REFRESH', false );

	define( 'WPVR_DISABLE_HS_BEACON', false );

	// define( 'WPVR_ENABLE_YOUTUBE', true );

	// define( 'WPVR_ENABLE_DAILYMOTION' , TRUE );

	// define( 'WPVR_ENABLE_VIMEO', false );

	define( 'WPVR_ENABLE_ADDONS', true );

	define( 'WPVR_ENABLE_SETTERS', true );

	define( 'WPVR_CLEAN_DUPS_THUMBS', false );

	define( 'WPVR_USE_MIN_CSS', true );

	define( 'WPVR_USE_LOCAL_FONTAWESOME', false );

	define( 'WPVR_USE_MIN_JS', true );

	define( 'WPVR_ENABLE_DATA_FILLERS', true );

	define( 'WPVR_ENABLE_POST_FORMATS', true );

	define( 'WPVR_FULL_DESC', false );

	define( 'WPVR_FORCE_ENGLISH_LANGUAGE', false );

	define( 'WPVR_REMOVE_THUMB_SINGLE', false );

	define( 'WPVR_REMOVE_FLOW_CONTENT', false );

	define( 'WPVR_REMOVE_FLOW_TAGS', false );

	define( 'WPVR_EG_FIX', false );

	define( 'WPVR_SMOOTH_SCREEN_ENABLED', false );

	define( 'WPVR_HIERARCHICAL_CATS_ENABLED', true );

	define( 'WPVR_BULK_IMPORT_BUFFER', 2 );

	define( 'WPVR_BATCH_ADDING_ENABLED', false );

	define( 'WPVR_MAX_EXECUTION_TIME', 600 );

	define( 'WPVR_FORCE_CREDENTIALS_API_CONNECT', false );

	define( 'WPVR_IS_DEMO', false );

	define( 'WPVR_MAIN_COLOR', '#fa6706' );

	define( 'WPVR_NONADMIN_CAP_OPTIONS', true );

	define( 'WPVR_NONADMIN_CAP_LOG', true );

	define( 'WPVR_NONADMIN_CAP_IMPORT', true );

	define( 'WPVR_NONADMIN_CAP_ACTIONS', true );

	define( 'WPVR_NONADMIN_CAP_MANAGE', true );

	define( 'WPVR_NONADMIN_CAP_DEFERRED', true );

	define( 'WPVR_ENABLE_ADMINBAR_MENU', true );

	define( 'WPVR_DEV_MODE', false );

	define( 'WPVR_ENABLE_TEST_VIDEO_INFO', true );

	define( 'WPVR_DISABLE_WP_META_OPTIMIZATION', false );

	define( 'WPVR_SOURCE_TABS_ENABLED', true );

	define( 'WPVR_ACTIONS_URL_ASYNC_FIX', true );

	define( 'WPVR_ENABLE_RANDOMIZE_SOURCE_SEARCH', false );

	define( 'WPVR_ENABLE_DASHBOARD_CHARTS_OPTIMIZATION', false );

	define( 'WPVR_DISABLE_JQUERY_ON_SCREENS', false );

	define( 'WPVR_ENABLE_AUTOUPDATE_DEBUG', false );

	define( 'WPVR_PAGINATION_FIX_ENABLE', false );

	define( 'WPVR_HTTP_AUTH_ENABLED', true );

	define( 'WPVR_HTTP_AUTH_USER', 'dev' );

	define( 'WPVR_HTTP_AUTH_PASSWORD', 'dev' );

	define( 'WPVR_SKIP_SSL_PEER_VERIFICATION', false );

	// define( 'WPVR_USE_PHP_SESSIONS', false );

	define( 'WPVR_USE_CART_COOKIE', false );

	define( 'WPVR_FORCE_FETCH_THUMBNAILS', false );

	define( 'WPVR_ENABLE_SOURCE_META_ENTRIES_MB', false );

	define( 'WPVR_ENABLE_VIDEO_META_ENTRIES_MB', false );

	define( 'WPVR_DISABLE_SOURCE_UNWANTED_TAB', false );

	define( 'WPVR_ENABLE_AUTOMATION_MANUAL_TEMPLATE', true );

	define( 'WPVR_ENABLE_DASHBOARD_METABOX', false );