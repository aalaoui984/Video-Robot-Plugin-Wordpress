<?php
	
	global $wpvr_cron_token;
	
	if ( ! isset( $_GET[ 'token' ] ) || empty( $_GET[ 'token' ] ) || $_GET[ 'token' ] != $wpvr_cron_token ) {
		echo "Invalid Token";
		exit;
	}
	global $cron_data_file;
	
	$cron_data_file = WPVR_PATH . 'assets/php/cron.txt';
	$cron_url       = WPVR_PATH . 'wpvr.cron.php';
	
	echo @d( $cron_url );
	
	include_once( $cron_url );