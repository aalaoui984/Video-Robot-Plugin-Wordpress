<?php


	class WPVR_Sources_Backend {


		public $cache = array();

		function __construct() {

			global $wpvr_unwanted_ids;


			add_action( 'plugins_loaded', array( $this, 'init_backend_hooks' ) );


		}

		public function init_backend_hooks() {

			add_filter( 'manage_edit-' . WPVR_SOURCE_TYPE . '_columns',
				array( $this, 'define_sources_backend_column' )
			);

			add_action( 'manage_' . WPVR_SOURCE_TYPE . '_posts_custom_column',
				array( $this, 'render_sources_backend_column' )
			);

			add_filter( 'manage_edit-' . WPVR_SFOLDER_TYPE . '_columns',
				array( $this, 'define_source_folders_backend_columns' )
			);


			add_action( 'manage_' . WPVR_SFOLDER_TYPE . '_custom_column',
				array( $this, 'render_source_folders_backend_columns' ), 10, 3
			);


		}

		public function render_source_folders_backend_columns( $value, $column_name, $folder_id ) {
			if ( $column_name == 'actions' ) {

				$base = add_query_arg( array(
					'page'      => WPVR_ID,
					'folder_id' => $folder_id,
				), admin_url( 'admin.php' ) );

				ob_start();
				?>
                <div class="wpvr_source_action_button pull-left">
                    <a href="<?php echo $base . '&test_sources'; ?>" target="_blank">
                        <i class="wpvr_link_icon fa fa-eye"></i>
						<?php echo __( 'Test', WPVR_LANG ); ?>
                    </a>
                </div>
                <div class="wpvr_source_action_button pull-left ">
                    <a href="<?php echo $base . '&run_sources'; ?>" target="_blank">
                        <i class="wpvr_link_icon fa fa-bolt"></i>
						<?php echo __( 'Run', WPVR_LANG ); ?>

                    </a>
                </div>
                <div class="wpvr_clearfix"></div>
                <div class="wpvr_source_action_button wpvr_black_button pull-left">
                    <a href="<?php echo $base . '&export_sources'; ?>" target="_blank">
                        <i class="wpvr_link_icon fa fa-upload"></i>
						<?php echo __( 'Export', WPVR_LANG ); ?>

                    </a>
                </div>
				<?php echo apply_filters( 'wpvr_extend_source_folder_column_actions', '', $folder_id ); ?>
				<?php
				$output = ob_get_contents();
				ob_end_clean();

				return $output;
			}

			return $value;
		}


		public function define_source_folders_backend_columns( $columns ) {
			$columns['actions'] = __( 'Sources Actions', WPVR_LANG );

			return $columns;
		}

		public function define_sources_backend_column( $columns ) {
			return apply_filters( 'wpvr_extend_source_backend_columns', array(
				'cb'      => '<input type="checkbox"/>',
				'name'    => __( 'Name', WPVR_LANG ),
				'stats'   => __( 'Stats', WPVR_LANG ),
				'info'    => __( 'Information', WPVR_LANG ),
				'options' => __( 'Settings', WPVR_LANG ),
				'status'  => __( 'Status', WPVR_LANG ),
			) );
		}

		public function render_sources_backend_column( $column ) {

			global $post;

			$post_status = 'publish';
			if ( isset( $_GET['post_status'] ) && ! empty( $_GET['post_status'] ) ) {
				$post_status = $_GET['post_status'];
			}

			$source_data = $this->get_single_source( $post->ID, $post_status );


			if ( isset( $source_data[ $column ] ) ) {
				echo $source_data[ $column ];

				return;
			}

			echo "";
		}

		function get_single_source( $source_id, $post_status = 'draft', $bypass_cache = false ) {

			if ( $bypass_cache === false && isset( $this->cache[ $source_id ] ) ) {
				// echo @d( 'Using cache' );

				return $this->cache[ $source_id ];
			}

			$source = wpvr_get_source( $source_id );

			if ( empty( $source ) ) {
				$this->cache[ $source_id ] = false;

				return false;
			}

			$source->post_status = $post_status;

			$this->cache[ $source_id ] = array(
				'stats'   => $this->get_single_source__stats( $source ),
				'options' => $this->get_single_source__options( $source ),
				'info'    => $this->get_single_source__info( $source ),
				'name'    => $this->get_single_source__name( $source ),
				'status'  => $this->get_single_source__status( $source ),
			);

			return $this->cache[ $source_id ];
		}

		public function get_single_source__stats( $source ) {
			global $wpvr_vs, $service_not_enabled;
			if ( ! isset( $wpvr_vs[ $source->service ] ) ) {
				return '';
			}

			$wantedVideos   = ( ! isset( $source->wantedVideos ) || ( $source->wantedVideos == '' ) ) ? 0 : $source->wantedVideos;
			$importedVideos = ( ! isset( $source->count_imported ) ) ? 0 : $source->count_imported;
			$count_test     = ( ! isset( $source->count_test ) ) ? 0 : $source->count_test;
			$count_run      = ( ! isset( $source->count_run ) ) ? 0 : $source->count_run;
			$count_success  = ( ! isset( $source->count_success ) ) ? 0 : $source->count_success;
			$count_fail     = ( ! isset( $source->count_fail ) ) ? 0 : $source->count_fail;

			if ( strpos( $source->type, 'channel' ) !== false ) {

				$ids_field = 'channelIds_' . $wpvr_vs[ $source->service ]['pid'];

				$subsources       = ! isset( $source->{$ids_field} ) ? 1 : count( wpvr_parse_string( $source->{$ids_field} ) );
				$subsources_label = __( 'channels', WPVR_LANG );
				$subsources_line  = '<b>' . wpvr_numberK( $subsources, true ) . '</b> ' . $subsources_label . '<br/>';

			} elseif ( strpos( $source->type, 'playlist' ) !== false ) {
				$ids_field        = 'playlistIds_' . $wpvr_vs[ $source->service ]['pid'];
				$subsources       = ! isset( $source->{$ids_field} ) ? 1 : count( wpvr_parse_string( $source->{$ids_field} ) );
				$subsources_label = __( 'playlists', WPVR_LANG );
				$subsources_line  = '<b>' . wpvr_numberK( $subsources, true ) . '</b> ' . $subsources_label . '<br/>';

			} else {
				$subsources      = 0;
				$subsources_line = '';
			}

			if ( $subsources > 1 ) {
				$wantedVideos = $subsources . 'x ' . wpvr_numberK( $wantedVideos );
			}

			$stats_insights = array(
				array(
					'label' => __( 'Wanted videos', WPVR_LANG ),
					'value' => $wantedVideos,
				),

				array(
					'label' => __( 'Imported videos', WPVR_LANG ),
					'value' => wpvr_numberK( $importedVideos ),
				),

				array(
					'full' => '<i></i><strong>' . wpvr_numberK( $count_test ) . '</strong> ' . __( 'Tests',
							WPVR_LANG ) .
					          '/ <strong>' . wpvr_numberK( $count_run ) . '</strong> ' . __( 'Runs', WPVR_LANG ),
				),
			);

			$last_executed_time = wpvr_get_source_last_executed_time( $source->id );

			if ( $last_executed_time !== false ) {

				$stats_insights[] = array(
					'icon'    => 'fa fa-bolt',
					'label'   => __( 'Executed', WPVR_LANG ),
					'value'   => ( $last_executed_time ),
					'reverse' => true,
				);
			}

			$stats_insights = apply_filters( 'wpvr_extend_source_stats_insights', $stats_insights, $source );

			ob_start();

			?>

			<?php foreach ( (array) $stats_insights as $row ) { ?>
				<?php $row = wp_parse_args( $row, array(
					'reverse' => false,
					'icon'    => '',
					'label'   => '',
					'value'   => 0,
					'full'    => false,
				) ); ?>
                <span class="wpvr_source_span">
                    <?php if ( $row['full'] !== false ) {
	                    echo $row['full'];

                    } else { ?>
	                    <?php if ( $row['reverse'] === true ) { ?>
                            <i class="<?php echo $row['icon']; ?>"></i>
	                    <?php echo( $row['label'] ); ?>
                        <strong><?php echo $row['value']; ?></strong>
	                    <?php } else { ?>
                            <i class="<?php echo $row['icon']; ?>"></i>
                            <strong><?php echo $row['value']; ?></strong>
		                    <?php echo( $row['label'] ); ?>
	                    <?php } ?>
                    <?php } ?>
            </span><br/>
			<?php } ?>

			<?php
			$output_string = ob_get_contents();
			ob_end_clean();

			return $output_string;
		}

		public function get_single_source__options( $source ) {
			global $wpvr_vs, $wpvr_options;
			if ( ! isset( $wpvr_vs[ $source->service ] ) ) {
				return '';
			}

			$source_settings = array();

			if ( defined( 'WPVR_DEV_MODE' ) && WPVR_DEV_MODE === true ) {
				$source_settings[] = '<span>Source #' . $source->id . '</span>';
			}


			/* FOLDERS */
			$folders = get_the_terms( $source->id, WPVR_SFOLDER_TYPE );
			if ( $folders != false ) {
				$folders_arr = array();
				foreach ( (array) $folders as $folder ) {
					$folders_arr[] = $folder->name;
				}
				$folders_str = implode( ', ', $folders_arr );
			} else {
				$folders_str = __( 'none', WPVR_LANG );
			}
			$source_settings[]
				= '
				<span class=" wpvr_source_span">
					<i class="fa fa-flag"></i>
					' . __( 'Folders', WPVR_LANG ) . ' : <strong>' . $folders_str . '</strong>
				</span>
			';

			/* POSTED BY */

			if ( $source->postAuthor == null || $source->postAuthor == 'default' ) {
				$source->postAuthor = $wpvr_options['postAuthor'];
			}
			$posting_author = get_userdata( $source->postAuthor );
			if ( $posting_author === false ) {
				global $wpvr_options;
				$posting_author   = get_userdata( $wpvr_options['postAuthor'] );
				$post_author_name = '(' . $posting_author->data->display_name . ')';
			} else {
				$post_author_name = $posting_author->data->display_name;
			}


			$source_settings[]
				= '
				<span class=" wpvr_source_span">
					<i class="fa fa-user"></i>
					' . __( 'Posting as', WPVR_LANG ) . ' ' . '<strong>' . $post_author_name . '</strong>
				</span>
			';

			global $wpvr_days_names;

			/* SCHEDULED ? */
			if ( $source->schedule == 'hourly' ) {
				$schedule_line_str = __( 'Scheduled', WPVR_LANG ) . '<b>' . ' ' . __( 'every hour',
						WPVR_LANG ) . '</b>';
			} elseif ( $source->schedule == 'daily' ) {
				$schedule_line_str = __( 'Scheduled', WPVR_LANG ) . '<b>' . ' ' .
				                     __( 'every', WPVR_LANG ) . ' ' . __( 'day', WPVR_LANG ) . ' ' . __( 'at',
						WPVR_LANG ) . ' ' .
				                     wpvr_get_time( $source->scheduleTime, false, false ) . '</b>';
			} elseif ( $source->schedule == 'weekly' ) {

				$schedule_line_str = __( 'Scheduled', WPVR_LANG ) . '<b>' . ' ' . __( 'every', WPVR_LANG ) . ' ' .
				                     strtolower( $wpvr_days_names[ $source->scheduleDay ] ) . ' ' .
				                     __( 'at', WPVR_LANG ) . ' ' . wpvr_get_time( $source->scheduleTime, false, false )
				                     . '</b>';
			} else {
				$schedule_line_str = __( 'Not scheduled', WPVR_LANG );
			}

			$source_settings[]
				= '
				<span class=" wpvr_source_span">
					<i class="fa fa-calendar"></i>
					<strong>
						' . apply_filters( 'wpvr_extend_schedules_overview', $schedule_line_str, $source->id ) . '
					</strong>
				</span>
			';

			/* POSTING CATS */

			if (
				$source->postCats != array( 0 )
				&& is_array( $source->postCats )
				&& count( $source->postCats ) != 0
				&& $source->postCats != false
			) {
				$cats = array();
				foreach ( (array) $source->postCats as $c ) {
					$cat = get_category( $c );
					if ( ! is_wp_error( $cat ) && $cat !== null ) {
						$cats[] = "<strong>" . $cat->name . "</strong> ";
					}
				}
				$source_settings[]
					= '
					<span class=" wpvr_source_span">
						<i class="fa fa-folder-open"></i>
						' . __( 'In', WPVR_LANG ) . ' ' . implode( ', ', $cats ) . '
					</span>
				';
			}

			$source_settings = apply_filters( 'wpvr_extend_source_column_settings', $source_settings, $source );

			return '<br/>' . implode( '<br/>', $source_settings );
		}

		public function get_single_source__info( $source ) {

			$source_creation_zoned = wpvr_get_zoned_formatted_time( $source->sourceDate ) .
			                         '<br/> (' . wpvr_get_timezone_name( wpvr_get_timezone() ) . ')';

			global $wpvr_vs, $service_not_enabled;
			if ( ! isset( $wpvr_vs[ $source->service ] ) ) {
				return '';
			}

			$echo = '';
			if ( isset( $wpvr_vs[ $source->service ]['types'][ $source->type ] ) ) {
				$echo .= ' ' . wpvr_render_vs_source_type( $wpvr_vs[ $source->service ]['types'][ $source->type ],
						$wpvr_vs[ $source->service ] ) . '<br/><br/>';
			}
			$echo .= '<span class=" wpvr_source_span">';
			$echo .= '<i class="fa fa-clock-o"></i>';
			$echo .= __( 'Created', WPVR_LANG ) . ' ' .
			         '<strong class="wpvr_tipso" title="' . $source_creation_zoned . '">' .
			         wpvr_human_time_diff( $source->id ) .
			         '</strong> <br/>';
			$echo .= '</span>';
			$echo .= '<span class=" wpvr_source_span">';
			$echo .= '<i class="fa fa-user"></i>';
			$echo .= 'By <b>' . get_the_author_meta( 'display_name', $source->sourceAuthor ) . '</b> <br/>';
			$echo .= '</span>';

			$echo .= '<span class=" wpvr_source_span">';
			$echo .= '<i class="fa fa-globe"></i>';
			$echo .= __( 'From', WPVR_LANG ) . '<b>' . ' ' . $wpvr_vs[ $source->service ]['label'] . '</b>';
			$echo .= '</span>  <br/>';


			$echo .= apply_filters( 'wpvr_extend_source_column_info', '', $source );

			return $echo;
		}

		public function get_single_source__status( $source ) {
			global $wpvr_vs, $service_not_enabled;
			if ( ! isset( $wpvr_vs[ $source->service ] ) ) {
				return '';
			}

			if ( $source->post_status === 'trash' ) {
				return '';
			}

			$toggleLink = WPVR_ACTIONS_URL . '?wpvr_wpload&toggle_sources';
			ob_start();
			?>

            <div
                    class="wpvr_source_status"
                    id="toggle_<?php echo $source->id; ?>"
                    url="<?php echo $toggleLink; ?>"
                    status="<?php echo $source->status; ?>"
            >
				<?php
					wpvr_make_switch_button_new(
						'',
						wpvr_get_button_state( $source->status, $invert = true ),
						'wpvr_source_toggle',
						$source->id
					);
				?>

                <div class="wpvr_toggle_loading" style="display:none;">
                    <i class="fa fa-spin fa-refresh"></i>
                </div>

                <div class="wpvr_toggle_done" style="display:none;">
                    <i class="fa fa-check"></i>
                </div>

            </div>
			<?php
			$status_html = ob_get_contents();
			ob_get_clean();

			return $status_html;

		}

		public function get_single_source__name( $source ) {
			global $wpvr_vs, $service_not_enabled;

			$duplicateLink = 'admin.php?post=' . $source->id . '&action=duplicate_source';
			$editLink      = get_edit_post_link( $source->id );
			$trashLink     = wpvr_get_post_links( $source->id, 'trash' );
			$untrashLink   = wpvr_get_post_links( $source->id, 'untrash' );
			$deleteLink    = wpvr_get_post_links( $source->id, 'delete' );
			$testLink      = admin_url( 'admin.php?page=' . WPVR_ID . '&test_sources&source_ids=' . $source->id );
			$runLink       = admin_url( 'admin.php?page=' . WPVR_ID . '&run_sources&ids=' . $source->id );
			$exportLink    = admin_url( 'admin.php?page=' . WPVR_ID . '&export_sources&ids=' . $source->id );

			if ( $source->name == '' ) {
				$source->name = __( 'Untitled Source', WPVR_LANG );
			}
			$source->name = apply_filters( 'wpvr_extend_admin_source_names', $source->name, $source->id );

			$name_line = sprintf( '<div class = "wpvr_source_name">%s</div>', strtoupper( $source->name ) );
			if ( ! isset( $wpvr_vs[ $source->service ] ) ) {
				// d( $source , $source->service );
				$actions_line = $service_not_enabled;
			} else {
				if ( $source->post_status == 'trash' ) {
					$actions_line
						= '
				<div class="wpvr_show_inline_when_loaded" style="display:none;">
				<div class = "wpvr_source_links">
					<a class = "wpvr_source_action_button pull-left" href = "' . $untrashLink . '">
						<i class = "wpvr_link_icon fa fa-reply"></i>
						' . __( 'Untrash', WPVR_LANG ) . '
					</a>
					<a class = "wpvr_source_action_button pull-left" href = "' . $deleteLink . '">
						<i class = "wpvr_link_icon fa fa-remove"></i>
						' . __( 'Delete', WPVR_LANG ) . '
					</a>
				</div>
				</div>
				';
				} else {
					$actions_line
						= '
					<div class="wpvr_show_inline_when_loaded" style="display:none;">
					<div class = "wpvr_source_links">
						<a href = "' . $editLink . '" class = "wpvr_source_action_button pull-left">
							<i class = "wpvr_link_icon fa fa-pencil"></i>
							' . __( 'Edit', WPVR_LANG ) . '
						</a>
						<a  href = "' . $trashLink . '" class = "wpvr_source_action_button pull-left">
							<i class = "wpvr_link_icon fa fa-trash"></i>
							' . __( 'Trash', WPVR_LANG ) . '
						</a>
						<a href = "' . $duplicateLink . '" class = "wpvr_source_action_button pull-left">
							<i class = "wpvr_link_icon fa fa-copy"></i>
							' . __( 'Clone', WPVR_LANG ) . '
						</a>
						<a class = "wpvr_source_action_button pull-left" href = "' . $testLink . '" target = "_blank">
							<i class = "wpvr_link_icon fa fa-eye"></i>
							' . __( 'Test', WPVR_LANG ) . '
						</a>
						<a class = "wpvr_source_action_button pull-left" href = "' . $runLink . '" target = "_blank">
							<i class = "wpvr_link_icon fa fa-bolt"></i>
							' . __( 'Run', WPVR_LANG ) . '
						</a>
						<a class = "wpvr_source_action_button pull-left" href = "' . $exportLink . '" target = "">
							<i class = "wpvr_link_icon fa fa-upload"></i>
							' . __( 'Export', WPVR_LANG ) . '
						</a>
						<a class = "wpvr_source_action_button wpvr_source_metrics_btn pull-left" href = "#" data-source= "' . $source->id . '">
							<i class = "wpvr_link_icon fa fa-bar-chart"></i>
							' . __( 'Metrics', WPVR_LANG ) . '
						</a>
					</div>
					</div>
					';
				}
			}

			$more = apply_filters( 'wpvr_extend_source_column_name', '', $source );

			return $name_line . $actions_line . $more;
		}


	}


	global $wpvrSourcesBackend;
	$wpvrSourcesBackend = new WPVR_Sources_Backend();

