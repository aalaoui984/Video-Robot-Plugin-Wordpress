<?php

	// Exit if accessed directly
	// if ( ! defined( 'ABSPATH' ) ) {
	// 	exit;
	// }

	define( 'WPVR_CLI_BASE', 'wpvr' );


	if ( ! class_exists( 'WP_CLI_Command' ) ) {
		return;
	}

	if( !defined( WP_CLI ) || !class_exists( WP_CLI ) ){
		return;
	}

	if ( ! class_exists( 'WPVR_Command_Line_Tool' ) ) {

		class WPVR_Command_Line_Tool extends WP_CLI_Command {

			private $queue;


			private $cache;
			private $labels;

			public function __construct() {


				$this->labels = array(
					'singular' => __( 'source', WPVR_LANG ),
					'plural'   => __( 'sources', WPVR_LANG ),
				);

			}

			private function cli_echo( $message = null ) {

				if ( $message === null ) {
					WP_CLI::line( "" );

					return;
				}

				$cli_name = 'VideoRobot';

				WP_CLI::line(
					WP_CLI::colorize( '%y[' . $cli_name . ']%n' ) .
					' ' .
					$message
				);

			}

			public function run( array $params = array(), array $args = array() ) {



				$is_dry_run = !isset( $args['exec'] );

				$query_args = array(
					'bypass_cache' => true,
					'scheduled'    => isset( $args['now'] ) ? 'now' : '',
					'status'       => isset( $args['now'] ) ? 'on' : '',
					'ids'          => isset( $args['ids'] ) ? explode( ',', $args['ids'] ) : null,
				);

				$sources = wpvr_get_sources( $query_args );

				// return false;
				$count_sources = count( $sources );

				// echo @d( $query_args , $sources );


				if ( $is_dry_run ) {

					if ( isset( $args['ids'] ) ) {

						if ( count( $sources ) === 0 ) {

							$this->cli_echo();
							$this->cli_echo( sprintf( "Could not find any source matching your IDs." ) );
							$this->cli_echo();

							return;

						}

						$this->cli_echo();

						$this->cli_echo( sprintf( "Found %s active %s.",
							$count_sources,
							$count_sources > 1 ? $this->labels['plural'] : $this->labels['singular']
						) );
						$this->cli_echo();

						return;

					}

					if ( isset( $args['now'] ) ) {

						if ( count( $sources ) === 0 ) {

							$this->cli_echo();
							$this->cli_echo( sprintf( "Could not find any active source scheduled now." ) );
							$this->cli_echo();

							return;

						}

						$this->cli_echo();

						$this->cli_echo( sprintf( "Found %s active %s scheduled now.",
							$count_sources,
							$count_sources > 1 ? $this->labels['plural'] : $this->labels['singular']
						) );
						$this->cli_echo();

						return;

					}

					return;
				}

				$this->cli_echo();
				$this->cli_echo( 'Running sources ...' );

				$report = wpvr_run_sources( $sources , true , false );

				// echo @d( $report );

				if( $report['status'] === true ) {

					$this->cli_echo( sprintf( "%d sources executed in %s seconds.",
						$report['count_sources'],
						$report['exec_time']
					) );

					$this->cli_echo( sprintf( "%d videos imported, %s deferred and %s skipped.",
						$report['count_added'],
						$report['count_deferred'],
						$report['count_skipped']
					) );

					return;

				}

				$this->cli_echo('Error: ' . $report['msg'] );


			}


			//List all sources
			public function list( array $params = array(), array $args = array() ) {

				$label = array(
					'singular' => 'source',
					'plural'   => 'sources',
				);


				$this->cli_echo();

				$this->cli_echo( sprintf( "Found %s active %s. Add --run to run them.",
					$this->cache['count'],
					$this->cache['count'] > 1 ? $label['plural'] : $label['singular']
				) );
				$this->cli_echo();

				return;

			}


		}

	}