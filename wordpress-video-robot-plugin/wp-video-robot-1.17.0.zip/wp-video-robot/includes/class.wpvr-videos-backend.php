<?php


	class WPVR_Videos_Backend {


		public $cache = array();

		public $available_post_types = array();
		public $handled_post_types = array();

		function __construct() {

			global $wpvr_unwanted_ids;

			$this->available_post_types = wpvr_get_available_post_types();
			$this->handled_post_types   = $handled_post_types = wpvr_cpt_get_handled_types( 'all', true );

			add_action( 'plugins_loaded', array( $this, 'init_backend_hooks' ) );


		}

		public function init_backend_hooks() {

			$extend_admin_columns = apply_filters( 'wpvr_extend_define_videos_columns', true );
			if ( $extend_admin_columns === false ) {
				return;
			}


			//Hook our functions to different handled post types
			foreach ( (array) $this->handled_post_types as $wpvr_cpt_get_handled_type ) {
				add_filter( 'manage_edit-' . $wpvr_cpt_get_handled_type . '_columns',
					array( $this, 'define_video_backend_columns' ), 1000, 1 );
				add_action( 'manage_' . $wpvr_cpt_get_handled_type . '_posts_custom_column',
					array( $this, 'render_video_backend_column' ), 1000, 1 );
			}


		}

		public function define_video_backend_columns( $columns ) {
			return apply_filters( 'wpvr_extend_video_backend_columns', array(
				'cb'          => '<input type="checkbox"/>',
				'video_thumb' => __( 'Thumbnail', WPVR_LANG ),
				'title'       => __( 'Title', WPVR_LANG ),
				'video_meta'  => __( 'Video Info', WPVR_LANG ),
				'video_data'  => '',
			) );
		}

		public function render_video_backend_column( $column ) {
			global $post, $wpvr_status, $wpvr_vs;
			$video_info          = $this->get_single_video( $post->ID );
			$wpvr_video_statuses = array( 'private', 'pending', 'publish', 'invalid', 'draft', 'trash' );
			$status              = $video_info['post_status'];

			if ( $column === 'video_thumb' ) {
				?>
                <div class="wpvr_thumb_box <?php echo $video_info['using_ext_thumbnail'] ? 'wpvr_external_thumb' : ''; ?> ">

					<?php if ( $video_info['using_ext_thumbnail'] ) { ?>
                        <span class="wpvr_external_thumb_flag">
                                <i class="fa fa-globe"></i>
                                External Thumbnail
                            </span>
					<?php } ?>

					<?php if ( $video_info['service'] != '' ) { ?>
                        <div class="wpvr_center wpvr_service_icon sharp <?php echo $video_info['service']; ?>">
							<?php if ( isset( $wpvr_vs[ $video_info['service'] ] ) ) { ?>
								<?php echo $wpvr_vs[ $video_info['service'] ]['label']; ?>
							<?php } else { ?>
								<?php echo $video_info['service']; ?>
							<?php } ?>
                        </div>
					<?php } ?>
					<?php if ( $video_info['service'] != '' && $video_info['is_unwanted'] ) { ?>
                        <div class="wpvr_center wpvr_is_unwanted">
                            <i class="fa fa-ban"></i>
                            <span><?php echo __( 'UNWANTED', WPVR_LANG ); ?></span>
                        </div>
					<?php } ?>

                    <div class="wpvr_video_actions" style="display:none;">

                        <a
                                class="wpvr_button small wpvr_edit_video"
                                href="<?php echo $video_info['edit_link']; ?>"
                        >
                            <i class="wpvr_link_icon fa fa-pencil"></i>
							<?php echo __( 'EDIT', WPVR_LANG ); ?>
                        </a>
                        <a
                                href="#"
                                class="wpvr_button small wpvr_preview_video wpvr_video_view"
                                url="<?php echo WPVR_MANAGE_URL; ?>"
                                service="<?php echo $video_info['service']; ?>"
                                video_id="<?php echo $video_info['video_id']; ?>"
                                post_id="<?php echo $video_info['post_id']; ?>"
                        >
                            <i class="wpvr_link_icon fa fa-eye"></i>
							<?php echo __( 'PREVIEW', WPVR_LANG ); ?>
                        </a>
                        <a
                                class="wpvr_button small wpvr_edit_video"
                                target="_blank"
                                href="<?php echo $video_info['view_link']; ?>"
                        >
                            <i class="wpvr_link_icon fa fa-external-link"></i>
							<?php echo __( 'VIEW', WPVR_LANG ); ?>
                        </a>

                    </div>
                    <div class="wpvr_video_actions_overlay" style="display:none;"></div>

					<?php if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) { ?>
                        <img class="" src="<?php echo $video_info['thumb_url']; ?>"/>
					<?php } else { ?>
                        <img class="wpvr_lazy_loaded" data-src="<?php echo $video_info['thumb_url']; ?>"/>
					<?php } ?>
                </div>
				<?php
                return;
			}

			if ( $column === 'video_data' ) {

				if ( $video_info['video_id'] == '' ) {
					return;
				}

				if ( ! isset( $wpvr_vs[ $video_info['service'] ] ) ) {
					echo __( 'Service disabled', WPVR_LANG );
					return;
				}

				?>
                <div style="">
					<?php if ( $video_info['service'] != '' ) { ?>
                        <div class="wpvr_center wpvr_service_icon <?php echo $video_info['service']; ?>">
							<?php echo $wpvr_vs[ $video_info['service'] ]['label'] . ' ' . __( 'video',
									WPVR_LANG ); ?>
                        </div>
					<?php } ?>

                    <div class="wpvr_center wpvr_video_admin_post_type">
						<?php echo __( 'Imported as',
								WPVR_LANG ) . ' <strong>' . $video_info['post_type_label'] . '</strong>'; ?>
                    </div>
                    <div class="wpvr_center wpvr_video_admin_id">
						<?php echo __( 'Video ID',
								WPVR_LANG ) . ': <strong style="text-transform:initial !important;">' . $video_info['video_id'] . '</strong>'; ?>
                    </div>

                    <div class="wpvr_center wpvr_video_admin_duration wpvr_video_admin_column">
						<?php if ( $video_info['is_live'] == '' ) {
							echo apply_filters( 'wpvr_extend_backend_video_duration',
								$video_info['duration'] != '' ? $video_info['duration'] : '', $video_info );
						} ?>

						<?php if ( $video_info['is_live'] == 'live' ) {
							echo '<i style="color:red;" class="fa fa-circle"></i> LIVE';
						} ?>
                    </div>

                    <div class="wpvr_center wpvr_video_admin_views wpvr_video_admin_column">
                        <b><?php echo wpvr_numberK( $video_info['views'] ); ?></b>
                        <span><?php _e( 'Views', WPVR_LANG ); ?></span>
                    </div>

                    <div class="wpvr_center wpvr_video_admin_views wpvr_video_admin_column">
                        <b><?php echo wpvr_numberK( $video_info['comment_count'] ); ?></b>
                        <span><?php _e( 'Comments', WPVR_LANG ); ?></span>
                    </div>

                    <div class="wpvr_clearfix"></div>

					<?php if ( in_array( $status, $wpvr_video_statuses ) ) { ?>
                        <div class="wpvr_center wpvr_video_status <?php echo $status; ?>">
                            <i class="fa wpvr_video_status_icon <?php echo $wpvr_status[ $status ]['icon']; ?>"></i>
							<?php echo $wpvr_status[ $status ]['label']; ?>
                        </div>
					<?php } ?>


                </div>
				<?php
				echo apply_filters( 'wpvr_extend_video_list_data_column', "", $post );
                return;
			}

			if ( $column === 'video_meta' ) {

				$echo = '';

				/* Echo Video Shortcode */
				$echo .= '<span class="wpvr_source_span">';
				$echo .= '<i class="fa fa-hashtag"></i>';
				$echo .= __( 'Post ID :', WPVR_LANG ) . ' ' . $video_info['post_id'];
				$echo .= '</span><br/>';


				if ( $video_info['import_date'] != '' ) {
					$echo .= '<span class=" wpvr_source_span">';
					$echo .= '<i class="fa fa-download"></i>';
					$echo .= __( 'Imported', WPVR_LANG ) .
					         ' <strong class="wpvr_tipso" title="' . $video_info['import_date_zoned'] . '">' .
					         $video_info['import_date'] .
					         '</strong> <br/>';
					$echo .= '</span>';
				}

				/* Echo Video Post Date */
				$echo .= '<span class=" wpvr_source_span">';
				$echo .= '<i class="fa fa-clock-o"></i>';
				$echo .= __( 'Posted', WPVR_LANG ) .
				         ' <strong class="wpvr_tipso" title="' . $video_info['post_date_zoned'] . '">' .
				         $video_info['post_date'] .
				         '</strong> <br/>';
				$echo .= '</span>';


				/* Echo Video Author */
				$echo .= '<span class=" wpvr_source_span">';
				$echo .= '<i class="fa fa-user"></i>';
				$echo .= __( 'Posted by', WPVR_LANG );
				$echo .= ' <b>' . $video_info['author_name'] . '</b> <br/>';
				$echo .= '</span>';

				/* Echo Video Categories */
				if ( !empty( $video_info['post_cats'] ) ) {
					$echo .= '<span class=" wpvr_source_span">';
					$echo .= '<i class="fa fa-folder-open"></i>';
					$echo .= __( 'Posted in', WPVR_LANG ) . ' ' . implode( ', ', $video_info['post_cats'] );
					$echo .= '</span><br/>';
				}

				/* Echo Video Source infos */
				if ( $video_info['source_name'] != '' ) {
					$echo .= '<span class=" wpvr_source_span">';
					$echo .= '<i class="fa fa-search"></i>';
					$echo .= __( 'Source :', WPVR_LANG );
					$echo .= ' <b>' . $video_info['source_name'] . '</b> <br/>';
					$echo .= '</span>';
				}

				/* Echo Video Autoembeding ? */
				if ( $video_info['disableAutoembed'] == 'on' ) {
					$echo .= '<span class=" wpvr_source_span">';
					$echo .= '<i class="fa fa-close"></i>';
					$echo .= __( 'Autoembedding Disabled.', WPVR_LANG );
					$echo .= '<br/></span>';
				}

				echo apply_filters( 'wpvr_extend_video_list_settings_column', $echo, $post );
                return;
            }


		}

		public function get_single_video( $post_id, $bypass_cache = false ) {

			if ( $bypass_cache === false && isset( $this->cache[ $post_id ] ) ) {
				// echo @d( 'Using Cache' );

				return $this->cache[ $post_id ];
			}

			global $wpvr_unwanted_ids;

			$post = get_post( $post_id );

			if ( empty( $post ) ) {

				$this->cache[ $post_id ] = false;

				return false;
			}

			$post_meta       = get_post_meta( $post_id );
			$post_comments   = wp_count_comments( $post_id );
			$post_categories = wp_get_post_categories( $post_id, array(
				'fields' => 'names',
			) );


			$user_timezone = wpvr_get_timezone();

			$post_date       = wpvr_human_time_diff( $post_id );
			$post_date_zoned = sprintf( '%s <br/> (%s)',
				wpvr_get_zoned_formatted_time( $post->post_date ),
				wpvr_get_timezone_name( $user_timezone )
			);

			$import_date       = isset( $post_meta['wpvr_video_importDate'] ) ? $post_meta['wpvr_video_importDate'][0] : '';
			$import_date_zoned = '';

			if ( ! empty( $import_date ) ) {
				$import_date       = wpvr_datetime_human_diff( $import_date );
				$import_date_zoned = sprintf( '%s <br/> (%s)',
					wpvr_get_zoned_formatted_time( $import_date ),
					wpvr_get_timezone_name( $user_timezone )
				);
			}

			$thumb_size = apply_filters(
				'wpvr_extend_backend_video_thumbnail_size',
				'wpvr_hard_thumb', $post_meta, $post_id
			);

			$ext_thumb_url = isset( $post_meta['wpvr_video_using_external_thumbnail'] ) ?
				$post_meta['wpvr_video_using_external_thumbnail'][0] : '';

			$author = get_user_by( 'id', $post->post_author );

			$video_info = array(
				'post_id'     => $post_id,
				'author_name' => isset( $author->display_name ) ? $author->display_name : '',

				'post_date'       => $post_date,
				'post_date_zoned' => $post_date_zoned,

				'import_date'       => $import_date,
				'import_date_zoned' => $import_date_zoned,

				'post_cats' => array(),

				'post_status' => $post->post_status,
				'video_id'    => isset( $post_meta['wpvr_video_id'][0] ) ?
					$post_meta['wpvr_video_id'][0] : '',
				'service'     => isset( $post_meta['wpvr_video_service'][0] ) ?
					$post_meta['wpvr_video_service'][0] : '',

				'post_type'       => $post->post_type,
				'post_type_label' => isset( $this->available_post_types[ $post->post_type ] ) ?
					$this->available_post_types[ $post->post_type ] : $post->post_type,

				'duration'            => wpvr_get_duration_string( isset( $post_meta['wpvr_video_duration'][0] ) ?
					$post_meta['wpvr_video_duration'][0] : ''
				),
				'views'               => isset( $post_meta['wpvr_video_views'][0] ) ? $post_meta['wpvr_video_views'][0] : 0,
				'is_live'             => isset( $post_meta['wpvr_video_is_live'][0] ) ? $post_meta['wpvr_video_is_live'][0] : '',
				'source_name'         => isset( $post_meta['wpvr_video_sourceName'][0] ) ? $post_meta['wpvr_video_sourceName'][0] : '',
				'disableAutoembed'    => isset( $post_meta['wpvr_video_disableAutoEmbed'][0] ) ? $post_meta['wpvr_video_disableAutoEmbed'][0] : 'off',
				'edit_link'           => get_edit_post_link( $post_id ),
				'view_link'           => get_the_permalink( $post_id ),
				'thumb_url'           => wpvr_get_video_thumbnail( $post_id, $thumb_size, $ext_thumb_url ),
				'using_ext_thumbnail' => ! empty( $ext_thumb_url ),
				'comment_count'       => $post_comments->total_comments,
			);

			$video_info['views']     = absint( $video_info['views'] );
			$video_info['thumb_url'] = $video_info['thumb_url'] === false ? WPVR_NO_THUMB : $video_info['thumb_url'];

			$video_info['is_unwanted'] = isset( $wpvr_unwanted_ids[ $video_info['service'] ][ $video_info['video_id'] ] ) ? true : false;

			if ( ! empty( $post_categories ) ) {
				foreach ( (array) $post_categories as $category_slug ) {
					$video_info['post_cats'][] = "<strong>" . $category_slug . "</strong>";
				}
			}

			$this->cache[ $post_id ] = $video_info;

			return $video_info;

		}


	}


	global $wpvrVideosBackend;
	$wpvrVideosBackend = new WPVR_Videos_Backend();

