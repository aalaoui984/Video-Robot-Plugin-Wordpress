<?php
	
	global $wpvr_pages , $wpvr_setters;
	$wpvr_pages = true;
	
	$setters = array(
		'left'  => array() ,
		'right' => array() ,
	);
	$i       = 1;
	
	// echo @d( $wpvr_setters );
	
	foreach ( (array) $wpvr_setters as $setter ) {
		$setter[ 'id' ] = $i;
		
		if ( ! isset( $setter[ 'show_result' ] ) ) {
			$setter[ 'show_result' ] = 0;
		}
		
		if ( $i % 2 == 0 ) {
			$setters[ 'right' ][] = $setter;
		} else {
			$setters[ 'left' ][] = $setter;
		}
		$i ++;
	}
	
	// echo @d( $setters );
	
?>

<div id = "dashboard-widgets-wrap">
	<div id = "dashboard-widgets" class = "metabox-holder">
		
		<div id = "postbox-container-1" class = "postbox-container">
			<div id = "normal-sortables" class = "meta-box-sortables ui-sortable">
				<?php foreach ( (array) $setters[ 'left' ] as $setter ) {
					if ( $setter[ 'action' ] == 'reset_using_default_meta_tables' && get_option( 'wpvr_meta_migration_done' ) !== false ) {
						continue;
					}
					?>
					<div id = "dashboard_right_now" class = "postbox ">
						<h3 class = "hndle"><span><?php echo $setter[ 'title' ]; ?></span></h3>
						<div class = "inside">
							<div class = "main">
								<p><?php echo $setter[ 'desc' ]; ?></p>
								<br/>
								<br/>
								
								<?php if ( $setter[ 'action' ] == 'reset_video_tables' ) {
									
									?>
									<button
											action = "<?php echo $setter[ 'action' ]; ?>"
											id = "<?php echo $setter[ 'id' ]; ?>"
											class = "wpvr_flush_button pull-right wpvr_button wpvr_large wpvr_setter_button"
											is_demo = "<?php echo WPVR_IS_DEMO ? 1 : 0; ?>"
											show_result = "<?php echo $setter[ 'show_result' ]; ?>"
											post_type = "all"
											post_type_label = ""
									>
										<i class = "wpvr_button_icon fa fa-bolt"></i>
										<?php echo __( 'Flush everything' , WPVR_LANG ); ?>
									</button>
									
									<div class = "wpvr_clearfix"></div>
									<?php
									
									$post_types = wpvr_cpt_get_handled_types( 'all' );
									foreach ( (array) $post_types as $post_type ) {
										$cpt = get_post_type_object( $post_type );
										if( $cpt === null ){
											continue;
										}
										?>
										<button
												action = "<?php echo $setter[ 'action' ]; ?>"
												id = "<?php echo $setter[ 'id' ]; ?>"
												class = "wpvr_flush_button pull-right wpvr_button wpvr_large wpvr_setter_button"
												is_demo = "<?php echo WPVR_IS_DEMO ? 1 : 0; ?>"
												show_result = "<?php echo $setter[ 'show_result' ]; ?>"
												post_type = "<?php echo $post_type; ?>"
												post_type_label = "<?php echo $cpt->label; ?>"
										>
											<i class = "wpvr_button_icon fa fa-bolt"></i>
											<?php echo sprintf( __( 'Flush %s' , WPVR_LANG ) , "{$cpt->label} [{$post_type}]" ); ?>
										</button>
									<?php }
								} else { ?>
									<button
											action = "<?php echo $setter[ 'action' ]; ?>"
											id = "<?php echo $setter[ 'id' ]; ?>"
											class = "pull-right wpvr_button wpvr_large wpvr_setter_button"
											is_demo = "<?php echo WPVR_IS_DEMO ? 1 : 0; ?>"
											show_result = "<?php echo $setter[ 'show_result' ]; ?>"
									>
										<i class = "wpvr_button_icon fa fa-bolt"></i>
										<?php echo $setter[ 'button' ]; ?>
									</button> <?php } ?>
								<div class = "wpvr_clearfix"></div>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
		
		<div id = "postbox-container-2" class = "postbox-container">
			<div id = "normal-sortables" class = "meta-box-sortables ui-sortable">
				<?php foreach ( (array) $setters[ 'right' ] as $setter ) { ?>
					<div id = "dashboard_right_now" class = "postbox ">
						<h3 class = "hndle"><span><?php echo $setter[ 'title' ]; ?></span></h3>
						<div class = "inside">
							<div class = "main">
								<p><?php echo $setter[ 'desc' ]; ?></p>
								<br/><br/>
								<button
										url = "<?php echo WPVR_SETTERS_URL; ?>"
										action = "<?php echo $setter[ 'action' ]; ?>"
										id = "<?php echo $setter[ 'id' ]; ?>"
										class = "pull-right wpvr_button wpvr_large wpvr_setter_button"
										is_demo = "<?php echo WPVR_IS_DEMO ? 1 : 0; ?>"
										show_result = "<?php echo $setter[ 'show_result' ]; ?>"
								>
									<i class = "wpvr_button_icon fa fa-bolt"></i>
									<?php echo $setter[ 'button' ]; ?>
								</button>
								<div class = "wpvr_clearfix"></div>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	
	</div>
</div>
