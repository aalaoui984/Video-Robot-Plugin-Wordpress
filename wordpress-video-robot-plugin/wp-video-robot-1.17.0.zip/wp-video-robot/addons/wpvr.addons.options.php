<?php
	
	if ( isset( $_GET['wpvr_wpload'] ) || isset( $_POST['wpvr_wpload'] ) ) {
		$t = explode( 'wp-content', dirname( __FILE__ ) );
		require_once( $t[0] . '/wp-load.php' );
		
		global $wpvr_addons;
		if ( isset( $_GET['id'] ) ) {
			$ca = $wpvr_addons[ $_GET['id'] ];
		} else {
			echo "no addon id defined. Exit.";
			
			return false;
		}
		
		
		//new dBug( $ca );
		
	}
	
	global $wpvr_options_tab, $wpvr_options_tab_label, $wpvr_pages;
	$wpvr_pages = true;
	if ( $wpvr_options_tab_label == null ) {
		$wpvr_options_tab_label = __( 'options', WPVR_LANG );
	}
	
	$slot_name = $ca['infos']['slot_name'];
	
	//d( $slot_name );
	
	$addon_id   = $ca['infos']['id'];
	$slot = wpvr_get_addon_options( $addon_id );
	
	//d( $slot );
 
	
	
	
	$has_options = false;
	if ( is_array( $ca['options'] ) && count( $ca['options'] ) != 0 ) {
		$has_options   = true;
		$addon_options = $ca['options'];
		foreach ( (array) $addon_options as $key => $row ) {
			$d[ $key ] = $row['order'];
		}
		array_multisort( $d, SORT_ASC, $addon_options );
	}
	
	// d( $addon_options );
	
	//Ordering OPTIONS
	$addon_options = wpvr_reorder_items( $addon_options , 'order' );
	
	// d( $addon_options );
	
	if ( $wpvr_options_tab == null ) {
		$wpvr_options_tab = '_main';
	}
	
	//d( $addon_options );
?>

<div class="wpvr_addon_options_wrapper" addon_id="<?php echo $addon_id; ?>">
    <div class="wpvr_addons_header">
		
		<?php do_action( 'wpvr_screen_addon_options_top', $addon_id, $ca ); ?>

        <button
                id="wpvr_save_addon_options"
                tab="<?php echo $wpvr_options_tab; ?>"
                type="submit"
                class="wpvr_save_addon_options pull-right wpvr_button"
        >
            <i class="wpvr_button_icon fa fa-save"></i>
			<?php echo __( 'Save', WPVR_LANG ) . ' ' . $wpvr_options_tab_label; ?>
        </button>

        <div class="wpvr_clearfix"></div>

    </div>
    <div class="wpvr_addons_options">
        <form class="wpvr_addons_options_form">
			<?php
				if ( $has_options === false ) {
					echo "No option found for this addon.";
				} else {
					foreach ( (array) $addon_options as $option ) {
						$option['addon_id'] = $addon_id;
						if ( ! isset( $option['tab'] ) ) {
							$option['tab'] = '_main';
						}
						
						if ( $wpvr_options_tab == $option['tab'] ) {
							if ( ! isset( $slot[ $option['id'] ] ) ) {
								$slot[ $option['id'] ] = null;
							}
							wpvr_addon_option_render( $option, $slot[ $option['id'] ] );
						}
					}
				}
			?>
        </form>
    </div>
    <div class="wpvr_addons_footer">
		<?php do_action( 'wpvr_screen_addon_options_bottom', $addon_id, $ca ); ?>
        <button
                data-addon="<?php echo $ca['infos']['title']; ?>"
                id="wpvr_reset_addon_options"
                class="pull-left wpvr_button wpvr_small wpvr_reset_addon_options wpvr_red_button"
        >
            <i class="wpvr_button_icon fa fa-ban"></i><?php _e( 'Reset to default', WPVR_LANG ); ?>
        </button>
        <button
                id="wpvr_save_addon_options_bis"
                tab="<?php echo $wpvr_options_tab; ?>"
                type="submit"
                class="wpvr_save_addon_options pull-right wpvr_button"
        >
            <i class="wpvr_button_icon fa fa-save"></i>
			<?php echo __( 'Save', WPVR_LANG ) . ' ' . $wpvr_options_tab_label; ?>
        </button>
        <div class="wpvr_clearfix"></div>

    </div>
    <div class="wpvr_clearfix"></div>
</div>