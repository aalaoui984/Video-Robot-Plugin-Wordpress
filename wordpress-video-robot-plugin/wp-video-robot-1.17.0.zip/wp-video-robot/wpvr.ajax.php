<?php
	
	
	include( 'ajax/wpvr.ajax.misc.php' );
	include( 'ajax/wpvr.ajax.manage.php' );
	include( 'ajax/wpvr.ajax.datafillers.php' );
	include( 'ajax/wpvr.ajax.setters.php' );
	include( 'ajax/wpvr.ajax.stages.php' );