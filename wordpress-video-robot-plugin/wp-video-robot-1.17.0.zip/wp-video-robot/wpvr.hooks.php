<?php
	
	
	
	require_once( 'hooks/wpvr.hooks.localize.php' );
	require_once( 'hooks/wpvr.hooks.assets.php' );
	require_once( 'hooks/wpvr.hooks.core.php' );
	require_once( 'hooks/wpvr.hooks.custom.php' );
	require_once( 'hooks/wpvr.hooks.menus.php' );
	
	require_once( 'hooks/wpvr.hooks.shortcodes.php' );
	require_once( 'hooks/wpvr.hooks.rewrite.php' );
	require_once( 'hooks/wpvr.hooks.conflicts.php' );
	
	require_once( 'hooks/wpvr.hooks.adapt.php' ); //@Todo Delete
	
	require_once( 'wpvr.custom.hooks.php' );
	
	if( is_admin() ){
		require_once( 'hooks/wpvr.hooks.themes.php' );
		require_once( 'hooks/wpvr.hooks.update.php' );
		require_once( 'hooks/wpvr.hooks.notices.php' );
		require_once( 'hooks/wpvr.hooks.migrate.php' );
	}
	require_once( 'meta/class.meta.videos.php' );
	require_once( 'meta/class.meta.sources.php' );

	