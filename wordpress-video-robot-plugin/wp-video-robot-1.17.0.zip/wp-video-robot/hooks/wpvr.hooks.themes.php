<?php
	
	global $wpvr_fixed_themes;
	
	$wpvr_fixed_themes = array();
	
	
	//Newsmag
	$wpvr_fixed_themes[] = array(
		'name'      => 'Newsmag' ,
		'title'     => 'Newsmag Theme' ,
		'fix'       => 'wpvr-tfng' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/newsmag-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/newsmag-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/newsmag/' ,
	);
	
	//Newspaper
	$wpvr_fixed_themes[] = array(
		'name'      => 'Newspaper' ,
		'title'     => 'Newspaper Theme' ,
		'fix'       => 'wpvr-tfnp' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/newspaper-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/newspaper-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/newspaper/' ,
	);
	
	//VideoPro
	$wpvr_fixed_themes[] = array(
		'name'      => 'VideoPro' ,
		'title'     => 'VideoPro Theme' ,
		'fix'       => 'wpvr-tfvp' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/videopro-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/videopro-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/videopro/' ,
	);
	
	//TrueMag
	$wpvr_fixed_themes[] = array(
		'name'      => 'TrueMag' ,
		'title'     => 'TrueMag Theme' ,
		'fix'       => 'wpvr-tftm' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/true-mag-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/true-mag-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/truemag/' ,
	);
	
	//Sahifa
	$wpvr_fixed_themes[] = array(
		'name'      => 'Sahifa' ,
		'title'     => 'Sahifa Theme' ,
		'fix'       => 'wpvr-tfs' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/sahifa-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/sahifa-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/sahifa/' ,
	);
	
	//Sahifa
	$wpvr_fixed_themes[] = array(
		'name'      => 'Jannah' ,
		'title'     => 'Jannah Theme' ,
		'fix'       => 'wpvr-themefix-jannah' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/jannah-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/jannah-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/jannah/' ,
	);
	
	//NewsTube
	$wpvr_fixed_themes[] = array(
		'name'      => 'NewsTube' ,
		'title'     => 'NewsTube Theme' ,
		'fix'       => 'wpvr-tfnt' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/newstube-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/newstube-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/newstube/' ,
	);
	
	//Videotube
	$wpvr_fixed_themes[] = array(
		'name'      => 'VideoTube' ,
		'title'     => 'VideoTube Theme' ,
		'fix'       => 'wpvr-tfvt' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/videotube-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/videotube-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/videotube/' ,
	);
	
	//Bimber
	$wpvr_fixed_themes[] = array(
		'name'      => 'Bimber' ,
		'title'     => 'Bimber Theme' ,
		'fix'       => 'wpvr-tfbm' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/bimber-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/bimber-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/bimber/' ,
	);
	
	//Valenti
	$wpvr_fixed_themes[] = array(
		'name'      => 'Valenti' ,
		'title'     => 'Valenti Theme' ,
		'fix'       => 'wpvr-tfvn' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/Valenti-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/Valenti-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/valenti/' ,
	);
	
	//Vlog
	$wpvr_fixed_themes[] = array(
		'name'      => 'Vlog' ,
		'title'     => 'Vlog Theme' ,
		'fix'       => 'wpvr-tfv' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/vlog-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/vlog-theme-fix-add-on-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/vlog/' ,
	);
	
	//Betube
	$wpvr_fixed_themes[] = array(
		'name'      => 'Betube' ,
		'title'     => 'Betube Theme' ,
		'fix'       => 'wpvr-tfbt' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/betube-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/betube-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/betube/' ,
	);
	
	//VideoTouch
	$wpvr_fixed_themes[] = array(
		'name'      => 'VideoTouch' ,
		'title'     => 'VideoTouch Theme' ,
		'fix'       => 'wpvr-tfvch' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/videotouch-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/videotouch-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/videotouch/' ,
	);
	
	//BoomBox
	$wpvr_fixed_themes[] = array(
		'name'      => 'BoomBox' ,
		'title'     => 'BoomBox Theme' ,
		'fix'       => 'wpvr-tfbb' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/boombox-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/boombox-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/boombox/' ,
	);
	
	//Top News
	$wpvr_fixed_themes[] = array(
		'disabled'  => TRUE ,
		'name'      => 'Top News' ,
		'title'     => 'Top News Theme' ,
		'fix'       => 'wpvr-tftn' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/top-news-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/top-news-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/topnews/' ,
	);
	
	//Slimvideo
	$wpvr_fixed_themes[] = array(
		'disabled'  => TRUE ,
		'name'      => 'Slimvideo' ,
		'title'     => 'Slimvideo Theme' ,
		'fix'       => 'wpvr-tfsv' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/slimvideo-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/slimvideo-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/slimvideo/' ,
	);
	
	//Snaptube
	$wpvr_fixed_themes[] = array(
		'disabled'  => TRUE ,
		'name'      => 'Snaptube' ,
		'title'     => 'Snaptube Theme' ,
		'fix'       => 'wpvr-tfst' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/snaptube-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/snaptube-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/snaptube/' ,
	);
	
	//King
	$wpvr_fixed_themes[] = array(
		'name'      => 'King' ,
		'title'     => 'King Theme' ,
		'fix'       => 'wpvr-tfkg' ,
		'store_url' => WPVR_STORE_URL_SSL . '/addon/king-theme-fix/' ,
		'tut_url'   => WPVR_SUPPORT_URL . '/tutorials/king-theme-fix-addon-tutorial/' ,
		'demo_url'  => WPVR_THEMES_DEMO_URL . '/king/' ,
	);