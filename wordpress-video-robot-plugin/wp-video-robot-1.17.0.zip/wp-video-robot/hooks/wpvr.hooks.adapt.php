<?php
	
	
	/*
	 * REplaced by the activation hook with wpvr_mysql_install
	*/
	//Adapt for v1.9.20 Backward
	// add_action( 'wpvr_adapt_install_after_update' , 'wpvr_adapt_install_after_update_meta_key_value_length' , 100 , 1 );
	// function wpvr_adapt_install_after_update_meta_key_value_length( $version ) {
	//
	// 	//Exit if doing an update newer than XXX
	// 	if ( version_compare( $version , '1.9.20' , '>' ) ) {
	// 		return false;
	// 	}
	//
	// 	global $wpdb;
	//
	// 	$done_source = @dbDelta( "CREATE TABLE {$wpdb->prefix}wpvr_source_meta (
	// 		`meta_id` INT(9) unsigned NOT NULL AUTO_INCREMENT,
	// 		`source_id` INT(9) unsigned NOT NULL DEFAULT '0',
	// 		`key_id` bigint(20) unsigned NOT NULL DEFAULT '0',
	// 		`meta_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
	// 		`meta_value` longtext COLLATE utf8mb4_unicode_ci,
	// 		PRIMARY KEY (`source_id` , `meta_key` , `meta_id`),
	// 		INDEX meta_id_index_meta (`meta_id`),
	// 		INDEX `meta_key_index_meta` (`meta_key`)
	// 	) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci" );
	//
	// 	$done_video = @dbDelta( "CREATE TABLE {$wpdb->prefix}wpvr_video_meta (
	// 			`meta_id` INT(9) unsigned NOT NULL AUTO_INCREMENT,
	// 			`video_id` INT(9) unsigned NOT NULL DEFAULT '0',
	// 			`key_id` bigint(20) unsigned NOT NULL DEFAULT '0',
	// 			`meta_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
	// 			`meta_value` longtext COLLATE utf8mb4_unicode_ci,
	// 			PRIMARY KEY (`video_id` , `meta_key` , `meta_id`),
	// 			INDEX meta_id_index_meta (`meta_id`),
	// 			INDEX `meta_key_index_meta` (`meta_key`)
	// 		) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci" );
	// }