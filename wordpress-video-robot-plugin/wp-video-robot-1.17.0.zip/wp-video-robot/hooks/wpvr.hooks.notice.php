<?php
	
	return false;
	add_action( 'init' , function () {
		
		$notices_class = WPVR_Notices();
		
		$notices = $notices_class->get();
		
		foreach ( (array) $notices as $notice ) {
			
			//echo $notices_class->render( $notice );
		}
	} , 100 );
	
	add_action( 'wp_ajax_nopriv_dismiss_notice' , 'wpvr_dismiss_notice_ajax_function' );
	add_action( 'wp_ajax_dismiss_notice' , 'wpvr_dismiss_notice_ajax_function' );
	function wpvr_dismisse_notice_ajax_function() {
		
		d( $_POST );
		
		$notices_class = WPVR_Notices();
		
		$user_id = get_current_user_id();
		
		$notices_class->dismiss( $_POST[ 'notice_slug' ] , $user_id );
		
		$message = 'OK';
		
		echo wpvr_get_json_response( $message );
		wpvr_die();
	}