<?php
	/*
	Plugin Name: WP Video Robot
	Plugin URI: https://www.wpvideorobot.com
	Description: The Ultimate WordPress Automated Video Importer
	Version: 1.17.0
	Author: pressaholic
	Author URI: https://www.wpvideorobot.com
	License: GPL2
	*/
	
	
	
	$wpvr_activation['act_status'] = '1';
	$wpvr_activation['purchaseCode'] = 'activated';
	$wpvr_activation['act_code'] = strrev ('bulc.evacllun');
	$wpvr_activation['act_email'] = 'mail@mail.com';
	$wpvr_activation['act_domain'] = get_site_url();
	$wpvr_activation['act_date'] = wp_date( 'F j, Y' );
	$wpvr_activation['buy_license'] = '';
	$wpvr_activations['wp-video-robot'] = $wpvr_activation;
	update_option( 'wpvr_activations', $wpvr_activations );
	
	define( 'WPVR_ID', 'wp-video-robot' );
	define( 'WPVR_MAIN_FILE', __FILE__ );
	define( 'WPVR_VERSION', '1.17.0' );
	
	require_once( 'wpvr.config.php' );
	
	/* Plugin Default Definitions */
	require_once( 'wpvr.definitions.php' );
	
	
	
	/* Including functions definitions */
	require_once( 'wpvr.functions.php' );
	
	/* Including functions definitions */
	require_once( 'wpvr.hooks.php' );
	
	/* Include AJAX definitions */
	require_once( 'wpvr.ajax.php' );
	
	/* Including Sources CPT definitions */
	if( is_admin() ){
		require_once( 'includes/wpvr.sources.php' );
		require_once( 'includes/wpvr.bulk.sources.php' );
		require_once( 'assets/php/RollingCurlX.php' );
	}

	
	/* Including Videos CPT definitions */
	require_once( 'includes/wpvr.videos.php' );
	require_once( 'includes/class.wpvr-videos-backend.php' );
	require_once( 'includes/class.wpvr-sources-backend.php' );

	/* Including Sources & Videos Bulk Action */
	
	require_once( 'includes/wpvr.bulk.videos.php' );

	if ( defined( 'WP_CLI' ) && WP_CLI && class_exists('WPVR_Command_Line_Tool') ) {

		require_once( 'includes/class.wpvr-cli.php' );
		WP_CLI::add_command( WPVR_CLI_BASE, 'WPVR_Command_Line_Tool' );
	}